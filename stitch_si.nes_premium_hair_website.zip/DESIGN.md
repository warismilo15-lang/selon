---
name: Atelier Minimalist
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e6'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0e0'
  on-secondary-container: '#616363'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c1b1a'
  on-tertiary-container: '#868382'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e6e2df'
  tertiary-fixed-dim: '#cac6c4'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#fdf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display:
    fontFamily: Cormorant Garamond
    fontSize: 4.5rem
    fontWeight: '300'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h1:
    fontFamily: Cormorant Garamond
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h2:
    fontFamily: Cormorant Garamond
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: '1.3'
  h3:
    fontFamily: Cormorant Garamond
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.7'
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  container-max: 1280px
  section-gap: 8rem
  element-gap: 1.5rem
  gutter: 2rem
  margin-page: 4rem
---

## Brand & Style
This design system embodies the essence of a high-end fashion editorial. It is built for a premium hair studio that treats hair as art, focusing on the intersection of modern sophistication and timeless elegance. The brand personality is poised, artistic, and exclusive.

The design style is strictly **Minimalist**. It relies on expansive whitespace, a restrained color palette, and high-contrast typography to create a sense of breathing room and luxury. The UI avoids unnecessary ornamentation, ensuring that the studio's photographic portfolio remains the focal point. Every element is intentional, creating an interface that feels like a curated gallery.

## Colors
The palette is rooted in a monochromatic foundation to maintain an editorial feel. **Deep Charcoal** provides the structural weight, used for primary interactions and heavy branding moments. **Pure White** and **Off White** are used to layer surfaces, providing depth without introducing new hues.

The **Rose Gold** accent is used sparingly—only for high-priority calls to action, active states, or subtle decorative accents. This ensures the metallic tone feels like a "signature" rather than a primary theme. Text is set in **Dark Charcoal** rather than pure black to soften the reading experience while maintaining accessibility.

## Typography
The typographic hierarchy relies on the tension between a romantic, editorial serif and a functional, modern sans-serif. **Cormorant Garamond** is used for all headlines to evoke the feel of a luxury masthead. Large "Display" sizes should be used with light weights to emphasize the artistic nature of the studio.

**Inter** handles all functional data and body copy. It provides a clean, neutral balance to the expressive headlines. Labels and small metadata should be set in uppercase Inter with increased letter spacing to maintain a "designer label" aesthetic.

## Layout & Spacing
This design system utilizes a **Fixed Grid** model with generous margins to enforce a premium, spacious feel. Sections are separated by significant vertical padding (Section Gaps) to allow the eye to rest and to treat each content block as a standalone piece of art.

The layout should prioritize asymmetry in image placement while keeping text aligned to a rigorous 12-column grid. Components should use an 8px spacing scale, but layout-level spacing should favor larger increments (64px, 96px, 128px) to prevent the UI from feeling "crowded" or "app-like."

## Elevation & Depth
Depth is achieved through **Tonal Layers** and **Low-Contrast Outlines** rather than traditional shadows. Surfaces should feel flat and architectural. 

- **Surface Tiers:** Use the background (Off White) as the base, with primary containers using Pure White to subtly lift them.
- **Borders:** Use 1px solid borders in a very light charcoal or semi-transparent rose gold for structural definition.
- **Glassmorphism:** Navigation bars and overlays may use a high-strength backdrop blur (20px+) with a 90% opacity white fill to mimic frosted glass, common in luxury storefronts.
- **Shadows:** If used, they must be "Ambient Shadows"—extremely diffused, 2-4% opacity, with no distinct direction.

## Shapes
To maintain an avant-garde and editorial aesthetic, this design system uses **Sharp** (0px) corners for all primary UI elements. Rectilinear shapes reflect the precision of high-end hair cutting and the architectural layout of professional photography.

Buttons, input fields, and image containers must remain perfectly rectangular. The only exception is for functional iconography, which should remain thin-stroked and geometric.

## Components
Consistent component styling reinforces the "editorial" directive:

- **Buttons:** Primary buttons are solid Deep Charcoal with Pure White text, sharp corners, and no shadow. Secondary buttons use a 1px Deep Charcoal border with no fill.
- **Input Fields:** Minimalist design—bottom border only (1px) in Deep Charcoal. Labels sit above in uppercase, tracked-out Inter.
- **Cards:** Borderless with images that bleed to the edge. Typography is placed either below the image with significant padding or as a delicate overlay.
- **Chips/Badges:** Small, sharp-edged rectangles with light Rose Gold backgrounds and Deep Charcoal text.
- **Lists:** Clean lines with thin dividers (1px) in a light neutral tint.
- **Custom Components:**
    - **Service Menu:** An accordion-style list using Cormorant Garamond for service names and Inter for pricing, emphasizing the contrast in styles.
    - **Booking Bar:** A persistent, minimal footer or header element in Pure White with a single Rose Gold CTA.